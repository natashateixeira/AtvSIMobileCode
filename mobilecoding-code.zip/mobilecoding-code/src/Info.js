import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Image } from 'react-native';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
    backgroundColor:'#ffffff'
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
  },
  img1: {
    width: 280,
    height: 310,
    marginTop: 25,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginTop:30,
    marginBottom: 10,
  },
  description: {
    fontSize: 16,
    textAlign: 'justify',
    marginBottom: 20,
  },
  subdescr:{
    fontSize:18,
    fontWeight:'bold',
    fontStyle:'italic',
    marginBottom:5
  },
  fotodescr: {
    fontSize: 10,
    marginTop: 5,
    marginBottom: 25,
  },
  botao: {
    width: 120,
    height: 45,
    borderWidth: 2,
    borderColor: '#4d4d4d',
    borderRadius: 25,
    marginBottom: 20,
  },
  btnTexto: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000000',
    textAlign: 'center',
    lineHeight: 45,
  },
});

const InfoPage = ({ fechar }) => {
  return (
    <ScrollView contentContainerStyle={styles.scrollContainer}
      showsVerticalScrollIndicator={false}>
      <View style={styles.container}>
        <Text style={styles.title}>Informações</Text>
        <Image source={require('../assets/citystops-1800px-noBG.png')} style={styles.img1} />

        <Text style={styles.fotodescr}>
          Logo do aplicativo Citystops
        </Text>

        <Text style={styles.subdescr}>
          Propósito do aplicativo
        </Text>

<Text style={styles.description}>
          O aplicativo Citystops surgiu com o propósito de compartilhar e conhecer lugares agradáveis pelo Recife, como livrarias, cafés, bares, restaurantes e pontos turísticos. A plataforma foi desenvolvida para ajudar tanto moradores quanto visitantes a descobrir os melhores locais da cidade, oferecendo uma experiência enriquecedora e autêntica.
        </Text>
        <Text style={styles.description}>
          Com uma interface amigável e fácil de usar, os usuários podem encontrar recomendações personalizadas com base em suas preferências e localização. Além disso, o Citystops permite que os usuários deixem avaliações e compartilhem suas experiências, criando uma comunidade ativa e engajada que contribui para a valorização e divulgação dos estabelecimentos locais.
        </Text>
        <Text style={styles.description}>
        Seja você um amante de livros à procura de uma livraria charmosa, um apreciador de café em busca do melhor espresso, ou um explorador urbano interessado em descobrir novos bares e restaurantes, o Citystops é a ferramenta ideal para transformar suas aventuras pelo Recife em momentos inesquecíveis.
        </Text>

        <TouchableOpacity style={styles.botao} onPress={fechar}>
          <Text style={styles.btnTexto}>Fechar</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

export default InfoPage;
