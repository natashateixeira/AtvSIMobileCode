import React, { Component } from 'react';
import { StyleSheet, Text, TextInput, View, TouchableOpacity, Alert, ScrollView } from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center'
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 20,
  },
  titulo: {
    fontWeight: 'bold',
    color: '#000000',
    fontSize: 22,
    textAlign: 'center',
    margin: 70
  },
  input: {
    width: 250,
    height: 40,
    borderWidth: 1,
    borderRadius: 6,
    borderColor: '#000000',
    marginHorizontal: 15,
    marginVertical: 8,
    fontSize: 18,
    padding: 10,
  },
  cepContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: 20,
  },
  inputCep: {
    flex: 1,
    width: 200,
    height: 40,
    borderWidth: 1,
    borderRadius: 6,
    borderColor: '#000000',
    marginHorizontal: 15,
    marginVertical: 8,
    fontSize: 18,
    padding: 10,
  },
  botaoCep: {
    height: 22,
    borderWidth: 1,
    borderColor: '#4d4d4d',
    borderRadius: 6,
    justifyContent: 'center',
    paddingHorizontal: 8,
  },
  botao: {
    width: 120,
    height: 45,
    borderWidth: 2,
    borderColor: '#4d4d4d',
    borderRadius: 25,
    marginTop: 20,
    justifyContent: 'center',
    alignItems: 'center'
  },
  btnTexto: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000000',
    textAlign: 'center',
  },
  btnTextoCep: {
    fontSize: 12,
    color: '#000000',
    textAlign: 'center',
  }
});

export default class Cadastrar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: '',
      usuario: '',
      senha: '',
      confirmarSenha: '',
      cep: '',
      estado: '',
      cidade: '',
      bairro: '',
      rua: ''
    };
  }

  //função pra validar formato do email
  validarEmail = (email) => {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
  };

  //função para buscar endereço pelo CEP
  buscarEndereco = async () => {
    const { cep } = this.state;
    try {
      const response = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
      const data = await response.json();
      if (data.erro) {
        Alert.alert('Erro', 'O CEP não foi encontrado.');
        return;
      }
      this.setState({
        estado: data.uf,
        cidade: data.localidade,
        bairro: data.bairro,
        rua: data.logradouro
      });
    } catch (error) {
      Alert.alert('Erro', 'Não foi possível buscar o endereço. Tente novamente.');
      console.error(error);
    }
  };

  cadastrar = async () => {
    const { email, usuario, senha, confirmarSenha, cep, estado, cidade, bairro, rua } = this.state;

    // verifica email e senha
    if (!this.validarEmail(email)) {
      Alert.alert('Erro', 'Por favor, insira um email válido.');
      return;
    }

    if (senha !== confirmarSenha) {
      Alert.alert('Erro', 'As senhas não coincidem');
      return;
    }

    // armazena
    try {
      await AsyncStorage.multiSet([
        ['email', email],
        ['usuario', usuario],
        ['senha', senha],
        ['cep', cep],
        ['estado', estado],
        ['cidade', cidade],
        ['bairro', bairro],
        ['rua', rua],
      ]);

      // limpa
      this.setState({
        email: '',
        usuario: '',
        senha: '',
        confirmarSenha: '',
        cep: '',
        estado: '',
        cidade: '',
        bairro: '',
        rua: ''
      });

      Alert.alert('Sucesso', 'Cadastro realizado com sucesso!');
    } catch (error) {
      console.error('Erro ao cadastrar:', error);
      Alert.alert('Erro', 'Erro ao cadastrar. Por favor, tente novamente.');
    }
  };

  render() {
    const { cep, estado, cidade, bairro, rua } = this.state;
    return (
      <View style={styles.container}>
        <ScrollView contentContainerStyle={styles.scrollContainer} showsVerticalScrollIndicator={false}>
          <Text style={styles.titulo}>Sign In</Text>
          <TextInput
            style={styles.input}
            placeholder="Email"
            onChangeText={(texto) => this.setState({ email: texto })}
            value={this.state.email}
            required={true}
          />
          <TextInput
            style={styles.input}
            placeholder="Nome de usuário"
            onChangeText={(texto) => this.setState({ usuario: texto })}
            value={this.state.usuario}
            required={true}
          />
          <TextInput
            style={styles.input}
            placeholder="Senha"
            secureTextEntry={true}
            onChangeText={(texto) => this.setState({ senha: texto })}
            value={this.state.senha}
            required={true}
          />
          <TextInput
            style={styles.input}
            placeholder="Confirme a senha"
            secureTextEntry={true}
            onChangeText={(texto) => this.setState({ confirmarSenha: texto })}
            value={this.state.confirmarSenha}
            required={true}
          />
          <View style={styles.cepContainer}>
            <TextInput
              style={[styles.inputCep, styles.inputCep]}
              placeholder="CEP"
              onChangeText={(texto) => this.setState({ cep: texto })}
              value={this.state.cep}
              required={true}
            />
            <TouchableOpacity style={styles.botaoCep} onPress={this.buscarEndereco}>
              <Text style={styles.btnTextoCep}>Buscar</Text>
            </TouchableOpacity>
          </View>
          <TextInput
            style={styles.input}
            placeholder="Estado"
            value={estado}
            editable={false}
          />
          <TextInput
            style={styles.input}
            placeholder="Cidade"
            value={cidade}
            editable={false}
          />
          <TextInput
            style={styles.input}
            placeholder="Bairro"
            value={bairro}
            editable={false}
          />
          <TextInput
            style={styles.input}
            placeholder="Rua"
            value={rua}
            editable={false}
          />
          <TouchableOpacity style={styles.botao} onPress={this.cadastrar}>
            <Text style={styles.btnTexto}>Cadastrar</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.botao} onPress={this.props.fechar}>
            <Text style={styles.btnTexto}>Voltar</Text>
          </TouchableOpacity>
        </ScrollView>
      </View>
    );
  }
}
